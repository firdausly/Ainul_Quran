package com.AinulQuran.model;



public class BillCode {
    public String BillCode;
}
