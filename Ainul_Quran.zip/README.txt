
Dont forget to import ainulquran.sql to database



To run, open project with intelliJ 
Configure the database in application.properties in src folder.


then click run 